export interface Interfaces {
  usuario: String;
  password: String;
}

export interface Contactenos {
  nombre: String;
  email: String;
  mensaje: String;
}
